// Подключение функционала "Чертогов Фрилансера"
import { isMobile } from "./functions.js";
// Подключение списка активных модулей
import { flsModules } from "./modules.js";

const observer = new IntersectionObserver((entries) => {
    let delay = 0;
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        // элемент стал видимым, выполняем анимацию
        setTimeout(() => {
          entry.target.classList.add('animate');
        }, delay);
        delay += 300; // добавляем задержку между карточками
      }
    });
  });
  
  // добавляем наблюдатель к элементам
  document.querySelectorAll('.scroll-item').forEach((item) => {
    observer.observe(item);
  });
